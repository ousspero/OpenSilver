using System;

namespace Bridge
{
    public static class Script
    {
        public static T Write<T>(string code, params object[] args)
        {
            throw new NotImplementedException();
        }

        public static void Write(string code, params object[] args)
        {
            throw new NotImplementedException();
        }
    }
}
