namespace Bridge
{
    public interface IBridgeClass
    {
    }
}