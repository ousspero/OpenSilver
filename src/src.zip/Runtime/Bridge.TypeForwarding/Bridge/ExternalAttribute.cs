﻿using System;

namespace Bridge
{
    public sealed class ExternalAttribute : Attribute
    {
    }
}