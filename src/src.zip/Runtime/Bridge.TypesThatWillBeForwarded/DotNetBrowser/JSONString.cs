﻿using System;

namespace DotNetBrowser
{
    public class JSONString
    {
        public JSONString(string value) { throw new NotImplementedException(); }

        public string Value { get { throw new NotImplementedException(); } }
    }
}
