﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.Text;

namespace System.Xaml
{
	static class ReflectionHelpers
	{
		public static readonly Type IXmlSerializableType = typeof(global::System.Xml.Serialization.IXmlSerializable);
	}
}
