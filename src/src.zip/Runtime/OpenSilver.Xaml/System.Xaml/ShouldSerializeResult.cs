﻿using System;
using System.Collections.Generic;
using System.Text;

namespace System.Xaml
{
	public enum ShouldSerializeResult
	{
		Default,
		True,
		False
	}
}
