﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace System.Xaml.Markup
{
	internal class StaticExtensionConverter : TypeConverter
	{
	}
}
